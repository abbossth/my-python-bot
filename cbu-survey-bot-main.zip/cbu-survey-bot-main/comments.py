
# def send_data_to_excel(chat_id):
#     # try:
#         # defining workbook
#         wb = openpyxl.load_workbook(EXCEL_PATH)

#         # defining worksheet
#         ws = wb['Responses']

#         try:
#             q0 = user_answers[chat_id][int(question_indexes["q0"])]
#             q0 = next(iter(q0)) if q0 else None
#         except:
#             q0 = "-"


#         try:
#             q1 = user_answers[chat_id][int(question_indexes["q1"])]
#             q1 = next(iter(q1)) if q1 else None
#         except:
#             q1 = "-"

#         try:
#             q3 = user_answers[chat_id][int(question_indexes["q3"])]
#             q3 = next(iter(q3)) if q3 else None
#         except:
#             q3 = "-"

#         try:
#             q4 = user_answers[chat_id][int(question_indexes["q4"])]
#             q4 = next(iter(q4)) if q4 else None
#         except:
#             q4 = "-"

#         try:
#             q5 = user_answers[chat_id][int(question_indexes["q5"])]
#             q5 = next(iter(q5)) if q5 else None
#         except:
#             q5 = "-"

#         try:
#             q6 = user_answers[chat_id][int(question_indexes["q6"])]
#             q6 = next(iter(q6)) if q6 else None
#         except:
#             q6 = "-"

#         try:
#             q7 = user_answers[chat_id][int(question_indexes["q7"])]
#             q7 = next(iter(q7)) if q7 else None
#         except:
#             q7 = "-"
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q8"])]
#             q8 = ""

#             for x in raw_value:
#                 if len(q8) > 0:
#                     q8 += ", "
#                 q8 += x
#         except:
#             q8 = "-"

#         try:
#             q9 = user_answers[chat_id][int(question_indexes["q9"])]
#             q9 = next(iter(q9)) if q9 else None
#         except:
#             q9 = "-"

#         # try:
#         #     q10 = user_answers[chat_id][int(question_indexes["q10"])]
#         #     q10 = next(iter(q10)) if q10 else None
#         # except:
#         #     q10 = "-"

#         try:
#             q11 = user_answers[chat_id][int(question_indexes["q11"])]
#             q11 = next(iter(q11)) if q11 else None
#         except:
#             q11 = "-"

#         try:
#             q12 = user_answers[chat_id][int(question_indexes["q12"])]
#             q12 = next(iter(q12)) if q12 else None
#         except:
#             q12 = "-"

#         try:
#             q13 = user_answers[chat_id][int(question_indexes["q13"])]
#             q13 = next(iter(q13)) if q13 else None
#         except:
#             q13 = "-"

#         try:
#             q14 = user_answers[chat_id][int(question_indexes["q14"])]
#             q14 = next(iter(q14)) if q14 else None
#         except:
#             q14 = "-"

#         try:
#             q15 = user_answers[chat_id][int(question_indexes["q15"])]
#             q15 = next(iter(q15)) if q15 else None
#         except:
#             q15 = "-"

#         try:
#             q16 = user_answers[chat_id][int(question_indexes["q16"])]
#             q16 = next(iter(q16)) if q16 else None
#         except:
#             q16 = "-"

#         try:
#             q17 = user_answers[chat_id][int(question_indexes["q17"])]
#             q17 = next(iter(q17)) if q17 else None
#         except:
#             q17 = "-"

#         try:
#             q18 = user_answers[chat_id][int(question_indexes["q18"])]
#             q18 = next(iter(q18)) if q18 else None
#         except:
#             q18 = "-"

#         try:
#             q19 = user_answers[chat_id][int(question_indexes["q19"])]
#             q19 = next(iter(q19)) if q19 else None
#         except:
#             q19 = "-"

#         try:
#             q20 = user_answers[chat_id][int(question_indexes["q20"])]
#             q20 = next(iter(q20)) if q20 else None
#         except:
#             q20 = "-"

#         try:
#             q21 = user_answers[chat_id][int(question_indexes["q21"])]
#             q21 = next(iter(q21)) if q21 else None
#         except:
#             q21 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q2"])]
#             q2 = ""

#             for x in raw_value:
#                 if len(q2) > 0:
#                     q2 += ", "
#                 q2 += x
#         except:
#             q2 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q10"])]
#             q10 = ""

#             for x in raw_value:
#                 if len(q10) > 0:
#                     q10 += ", "
#                 q10 += x
#         except:
#             q10 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q22"])]
#             q22 = ""

#             for x in raw_value:
#                 if len(q22) > 0:
#                     q22 += ", "
#                 q22 += x
#         except:
#             q22 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q24"])]
#             q24 = ""

#             for x in raw_value:
#                 if len(q24) > 0:
#                     q24 += ", "
#                 q24 += x
#         except:
#             q24 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q28"])]
#             q28 = ""

#             for x in raw_value:
#                 if len(q28) > 0:
#                     q28 += ", "
#                 q28 += x
#         except:
#             q28 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q34"])]
#             q34 = ""

#             for x in raw_value:
#                 if len(q34) > 0:
#                     q34 += ", "
#                 q34 += x
#         except:
#             q34 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q36"])]
#             q36 = ""

#             for x in raw_value:
#                 if len(q36) > 0:
#                     q36 += ", "
#                 q36 += x
#         except:
#             q36 = "-"

#         # Multiple Option Selection
#         try:
#             raw_value = user_answers[chat_id][int(question_indexes["q39"])]
#             q39 = ""

#             for x in raw_value:
#                 if len(q39) > 0:
#                     q39 += ", "
#                 q39 += x
#         except:
#             q39 = "-"

#         try:
#             q23 = user_answers[chat_id][int(question_indexes["q23"])]
#             q23 = next(iter(q23)) if q23 else None
#         except:
#             q23 = "-"

#         # try:
#         #     q24 = user_answers[chat_id][int(question_indexes["q24"])]
#         #     q24 = next(iter(q24)) if q24 else None
#         # except:
#         #     q24 = "-"

#         try:
#             q25 = user_answers[chat_id][int(question_indexes["q25"])]
#             q25 = next(iter(q25)) if q25 else None
#         except:
#             q25 = "-"

#         try:
#             q26 = user_answers[chat_id][int(question_indexes["q26"])]
#             q26 = next(iter(q26)) if q26 else None
#         except:
#             q26 = "-"


#         try:
#             q27 = user_answers[chat_id][int(question_indexes["q27"])]
#             q27 = next(iter(q27)) if q27 else None
#         except:
#             q27 = "-"

#         try:
#             q29 = user_answers[chat_id][int(question_indexes["q29"])]
#             q29 = next(iter(q29)) if q29 else None
#         except:
#             q29 = "-"

#         try:
#             q30 = user_answers[chat_id][int(question_indexes["q30"])]
#             q30 = next(iter(q30)) if q30 else None
#         except:
#             q30 = "-"

#         try:
#             q31 = user_answers[chat_id][int(question_indexes["q31"])]
#             q31 = next(iter(q31)) if q31 else None
#         except:
#             q31 = "-"

#         try:
#             q32 = user_answers[chat_id][int(question_indexes["q32"])]
#             q32 = next(iter(q32)) if q32 else None
#         except:
#             q32 = "-"

#         try:
#             q33 = user_answers[chat_id][int(question_indexes["q33"])]
#             q33 = next(iter(q33)) if q33 else None
#         except:
#             q33 = "-"

#         try:
#             q35 = user_answers[chat_id][int(question_indexes["q35"])]
#             q35 = next(iter(q35)) if q35 else None
#         except:
#             q35 = "-"

#         try:
#             q37 = user_answers[chat_id][int(question_indexes["q37"])]
#             q37 = next(iter(q37)) if q37 else None
#         except:
#             q37 = "-"

#         try:
#             q38 = user_answers[chat_id][int(question_indexes["q38"])]
#             q38 = next(iter(q38)) if q38 else None
#         except:
#             q38 = "-"



#         # QUESTION 2 SUB ANSWERS
#         try:
#             q2_a1 = user_answers[chat_id][int(question_indexes["q2_a1"])]
#             q2_a1 = next(iter(q2_a1)) if q2_a1 else None
#         except:
#             q2_a1 = "-"
#         try:
#             q2_a2 = user_answers[chat_id][int(question_indexes["q2_a2"])]
#             q2_a2 = next(iter(q2_a2)) if q2_a2 else None
#         except:
#             q2_a2 = "-"
#         try:
#             q2_a3 = user_answers[chat_id][int(question_indexes["q2_a3"])]
#             q2_a3 = next(iter(q2_a3)) if q2_a3 else None
#         except:
#             q2_a3 = "-"
#         try:
#             q2_a4 = user_answers[chat_id][int(question_indexes["q2_a4"])]
#             q2_a4 = next(iter(q2_a4)) if q2_a4 else None
#         except:
#             q2_a4 = "-"
#         try:
#             q2_a5 = user_answers[chat_id][int(question_indexes["q2_a5"])]
#             q2_a5 = next(iter(q2_a5)) if q2_a5 else None
#         except:
#             q2_a5 = "-"
#         try:
#             q2_a6 = user_answers[chat_id][int(question_indexes["q2_a6"])]
#             q2_a6 = next(iter(q2_a6)) if q2_a6 else None
#         except:
#             q2_a6 = "-"
#         try:
#             q2_a7 = user_answers[chat_id][int(question_indexes["q2_a7"])]
#             q2_a7 = next(iter(q2_a7)) if q2_a7 else None
#         except:
#             q2_a7 = "-"
#         try:
#             q2_a8 = user_answers[chat_id][int(question_indexes["q2_a8"])]
#             q2_a8 = next(iter(q2_a8)) if q2_a8 else None
#         except:
#             q2_a8 = "-"
#         try:
#             q2_a9 = user_answers[chat_id][int(question_indexes["q2_a9"])]
#             q2_a9 = next(iter(q2_a9)) if q2_a9 else None
#         except:
#             q2_a9 = "-"
#         try:
#             q2_a10 = user_answers[chat_id][int(question_indexes["q2_a10"])]
#             q2_a10 = next(iter(q2_a10)) if q2_a10 else None
#         except:
#             q2_a10 = "-"
#         try:
#             q2_a11 = user_answers[chat_id][int(question_indexes["q2_a11"])]
#             q2_a11 = next(iter(q2_a11)) if q2_a11 else None
#         except:
#             q2_a11 = "-"
#         try:
#             q2_a12 = user_answers[chat_id][int(question_indexes["q2_a12"])]
#             q2_a12 = next(iter(q2_a12)) if q2_a12 else None
#         except:
#             q2_a12 = "-"
#         try:
#             q2_a13 = user_answers[chat_id][int(question_indexes["q2_a13"])]
#             q2_a13 = next(iter(q2_a13)) if q2_a13 else None
#         except:
#             q2_a13 = "-"

#         # form list of new data
#         new_data = [chat_id, lang[chat_id], q0, q1, q2, q2_a1, q2_a2, q2_a3, q2_a4, q2_a5, q2_a6, q2_a7, q2_a8, q2_a9, q2_a10, q2_a11,
#                     q2_a12, q2_a13, q3, q4, q5, q6, q7, q8, q9, q10, q11, q12, q13, q14, q15, q16, q17, q18, q19, q20,
#                     q21, q22, q23, q24, q25, q26, q27, q28, q29, q30, q31, q32, q33, q34, q35, q36, q37, q38, q39]

#         # appending data to excel file
#         ws.append(new_data)

#         # saving changes
#         wb.save(EXCEL_PATH)

#     # except:
#     #     print("Something went wrong in saving data!")
#     #     return bot.send_message(chat_id, "Error in saving data!")


# # ----------------------------------------------------------------------------
# # DATA SENDER HANDLER: THIS HANDLER WILL SEND EXCEL DOCUMENT TO SPECIFIC USERS
# @bot.message_handler(commands=['data'])
# def data(message):
#     file = open(EXCEL_PATH, 'rb')
#     bot.send_document(message.from_user.id, file, caption=time.asctime())

