import psycopg2
DATABASE_URL = "postgres://postgres:test1234@127.0.0.1:5432/surveydb"
def db_setup():
    print("Hello")
    # Connect to the local PostgreSQL database
    try:
        conn = psycopg2.connect(DATABASE_URL)

        cursor = conn.cursor()

        create_users_table = """
            CREATE TABLE IF NOT EXISTS Users (
                id SERIAL PRIMARY KEY,
                user_id INTEGER UNIQUE,
                chosen_language VARCHAR(128),
                current_question_order INTEGER,
                is_survey_finished BOOLEAN,
                join_date TIMESTAMP
            );
            """
        create_responses_table = """
            CREATE TABLE IF NOT EXISTS responses (
                id SERIAL PRIMARY KEY,
                user_id INTEGER REFERENCES Users(user_id),
                question_order INTEGER,
                question_text varchar(256),
                option_text varchar(128),
                language varchar(64)
            );
            """
        cursor.execute(create_users_table)
        cursor.execute(create_responses_table)
        conn.commit()
        print("Tables created successfully!")
        # Close the database connection
        cursor.close()
        conn.close()

    except Exception as ex:
        print(f"Database connection failed... {ex}")


# create new user
def new_user(user_id):
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        insert_query = f"""
        INSERT INTO users (user_id, current_question_order, is_survey_finished, join_date)
        VALUES ({user_id}, 0, False, NOW());
        """
        cursor.execute(insert_query)
        conn.commit()
        print("User created successfully!")
        cursor.close()
        conn.close()
    except Exception as _ex:
        print(f"Error in creating new user. {_ex}")
        conn.rollback()

# create new user
def new_record(user_id, question_order, question_text, option_text, language):
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        insert_query = f"""
        INSERT INTO responses (user_id, current_question_order, is_survey_finished, join_date)
        VALUES ({user_id}, {question_order}, '{question_text}', '{option_text}', '{language}');
        """
        cursor.execute(insert_query)
        conn.commit()
        print("Record created successfully!")
        cursor.close()
        conn.close()
    except Exception as _ex:
        print(f"Error in creating new record. {_ex}")
        conn.rollback()

# choose language
def set_language(user_id, language):
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        insert_query = f"""
        UPDATE users SET 
        chosen_language = '{language}'
        WHERE user_id = {user_id};
        """
        cursor.execute(insert_query)
        conn.commit()
        print("Language set successfully!")
    except Exception as _ex:
        print(f"Error in setting language to user {user_id}. {_ex}")
        conn.rollback()

# increment order num
def increment_order_num(user_id, num):
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        insert_query = f"""
        UPDATE users SET 
        current_question_order = {num}
        WHERE user_id = {user_id};
        """
        cursor.execute(insert_query)
        conn.commit()
        print("Incremented successfully!")
    except Exception as _ex:
        print(f"Error in incrementing order num to user {user_id}. {_ex}")
        conn.rollback()

# select all users
def select_users():
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM USERS LIMIT 100")
        result = cursor.fetchall()
        cursor.close()
        conn.close()
        return result
    except Exception as _ex:
        print(f"Error in fetching users. {_ex}")
        return _ex

# select one user with id
def select_user(user_id):
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cursor = conn.cursor()
        cursor.execute(f"SELECT * FROM USERS WHERE user_id = {user_id}")
        user_exists = cursor.fetchall()
        cursor.close()
        conn.close()
        return user_exists
    except Exception as _ex:
        print(f"Error in fetching user with id: {user_id}. {_ex}")
        return _ex
