import time
import telebot
from telebot import types
import config
from data import questions, questions_uz, questions_uz_latin
from question_indexes import question_indexes
from config import EXCEL_PATH
from db import db_setup, select_user, set_language, increment_order_num, new_user, select_users, new_record

# Replace 'YOUR_BOT_TOKEN' with your actual bot token obtained from BotFather
bot = telebot.TeleBot(config.BOT_TOKEN)

# bot languages
languages = [{"code": "uz_latin", "text": "O'zbek tili"}, {"code": "uz_kiril", "text": "Ўзбек тили"}, {"code": "ru", "text": "Русский язык"}]

# chosen language || by default it is *ru*
lang = {}

# Keep track of user answers
user_answers = {}

# Keep track of the current question for each user
user_current_question = {}


# Helper function to generate inline keyboard markup
def generate_markup(question, answers):
    select_symbol = "⚪️"
    if int(question) == question_indexes["q2"] or int(question) == question_indexes["q10"] or int(question) == question_indexes["q24"] or int(question) == question_indexes["q8"] or int(question) == question_indexes["q22"] or int(question) == question_indexes["q28"] or int(question) == question_indexes["q34"] or int(question) == question_indexes["q36"] or int(question) == question_indexes["q39"]:
        # select_symbol = "☐"
        select_symbol = "◻️"
    elif int(question) == question_indexes["q2_next"] or int(question) == question_indexes["q10_next"] or int(question) == question_indexes["q24_next"] or int(question) == question_indexes["next"] or int(question) == question_indexes["q22_next"] or int(question) == question_indexes["q28_next"] or int(question) == question_indexes["q34_next"] or int(question) == question_indexes["q36_next"] or int(question) == question_indexes["q39_next"]:
        select_symbol = ">>"

    markup = types.InlineKeyboardMarkup(row_width=2)
    for answer in answers:
        markup.add(types.InlineKeyboardButton(text=f"{select_symbol} {answer}", callback_data=f"{question}_{answer}_none"))
    return markup


# Helper function to generate inline keyboard markup
def generate_markup_languages():
    markup = types.InlineKeyboardMarkup(row_width=2)
    btn1 = types.InlineKeyboardButton(f"O'zbek Tili", callback_data=f"uz_latin")
    btn2 = types.InlineKeyboardButton(f"Ўзбек тили", callback_data=f"uz_kiril")
    btn3 = types.InlineKeyboardButton(f"Русский язык", callback_data=f"ru")
    markup.add(btn1, btn2, btn3)
    return markup


# finish
def send_survey_finish_message(chat_id):
    # send_data_to_excel(chat_id)
    if lang[chat_id] == "uz_kiril":
        return bot.send_message(chat_id, f"<b>Сўровномамизда иштирок этганингиз учун ташаккур! Сизнинг фикрингиз биз учун қадрлидир.</b>", parse_mode='HTML')
    elif lang[chat_id] == "uz_latin":
        return bot.send_message(chat_id, f"<b>So'rovnomada ishtiroq etganingiz uchun tashakkur! Sizning fikringiz biz uchun qadrlidir</b>", parse_mode='HTML')
    else:
        return bot.send_message(chat_id, f"<b>Благодарим вас за участие в нашем опросе! Ваше мнение для нас ценно. </b>", parse_mode='HTML')


# Handler for start command
@bot.message_handler(commands=['start', 'survey'])
def handle_start(message):
    ChatId = message.chat.id
    db_setup()
    user = select_user(ChatId)
    if user:
        increment_order_num(ChatId, 0)
    else:
        new_user(ChatId)
    bot.send_message(ChatId, f"<b>{message.from_user.first_name},</b> Аҳоли қарз юкини аниқлаш бўйича сўровномага хуш келибсиз!\nИлтимос, тилни танланг\n\n<b>{message.from_user.first_name},</b> Добро пожаловать в опросник по определению долговой нагрузки населения!\nПожалуйста, выберите язык", parse_mode='HTML',  reply_markup=generate_markup_languages())

# Send survey question
def send_question(chat_id):
    user = select_user(chat_id)
    current_question = user[0][3]
    lang = user[0][2]

    # # Q4
    # q4_answer = user_answers[chat_id].get(question_indexes["q4"]) if user_answers else None
    # q4_value = next(iter(q4_answer)) if q4_answer else None
    # if current_question == question_indexes["q4"] + 1:
    #     if q4_value == "нет" or q4_value == "йўқ" or q4_value == "yo‘q":
    #         q = question_indexes["q4"] + 1
    #         user_current_question[chat_id] += 1
    #         if int(q) not in user_answers:
    #             user_answers[chat_id][int(q)] = set()
    #         user_answers[chat_id][q].add("-")

    # # Q7
    # q7_index = question_indexes["q7"]
    # q7_answer = user_answers[chat_id].get(q7_index) if user_answers else None
    # q7_value = next(iter(q7_answer)) if q7_answer else None
    # if current_question == q7_index + 1:
    #     if q7_value == "нет" or q7_value == "йўқ" or q7_value == "yo‘q":
    #         user_current_question[chat_id] = question_indexes["q21"]

    # # Q9
    # q9_index = question_indexes["q9"]
    # q9_answer = user_answers[chat_id].get(q9_index) if user_answers else None
    # q9_value = next(iter(q9_answer)) if q9_answer else None
    # if current_question == q9_index + 1:
    #     if q9_value == "нет" or q9_value == "йўқ" or q9_value == "yo‘q":
    #         q = q9_index + 2
    #         user_current_question[chat_id] += 2
    #         if int(q) not in user_answers:
    #             user_answers[chat_id][int(q)] = set()
    #         user_answers[chat_id][q].add("-")

    # # Q21
    # q21_index = question_indexes["q21"]
    # q21_answer = user_answers[chat_id].get(q21_index) if user_answers else None
    # q21_value = next(iter(q21_answer)) if q21_answer else None
    # if current_question == q21_index + 1:
    #     if q21_value == "нет" or q21_value == "йўқ" or q21_value == "yo‘q":
    #         user_current_question[chat_id] = question_indexes["q27"]
    #         current_question = question_indexes["q27"]

    # # Q23
    # q23_index = question_indexes["q23"]
    # q23_answer = user_answers[chat_id].get(q23_index) if user_answers else None
    # q23_value = next(iter(q23_answer)) if q23_answer else None
    # if current_question == q23_index + 1:
    #     if q23_value == "нет" or q23_value == "йўқ" or q23_value == "yo‘q":
    #         user_current_question[chat_id] = question_indexes["q25"]
    #         current_question = question_indexes["q25"]

    # # Q27
    # q27_index = question_indexes["q27"]
    # q27_answer = user_answers[chat_id].get(q27_index) if user_answers else None
    # q27_value = next(iter(q27_answer)) if q27_answer else None
    # if current_question == q27_index + 1:
    #     if q27_value == "нет" or q27_value == "йўқ" or q27_value == "yo‘q":
    #         user_current_question[chat_id] = question_indexes["q31"]
    #         current_question = question_indexes["q31"]

    # # MULTIPLE CONDITIONS FOR QUESTIONS 32-38
    # if current_question == question_indexes["q31"]:
    #     if q7_value == "нет" and q21_value == "нет" and q27_value == "нет":
    #         user_current_question[chat_id] = question_indexes["q38"]
    #         current_question = question_indexes["q38"]
    #     elif q7_value == "йўқ" and q21_value == "йўқ" and q27_value == "йўқ":
    #         user_current_question[chat_id] = question_indexes["q38"]
    #         current_question = question_indexes["q38"]
    #     elif q7_value == "yo‘q" and q21_value == "yo‘q" and q27_value == "yo‘q":
    #         user_current_question[chat_id] = question_indexes["q38"]
    #         current_question = question_indexes["q38"]

    # # Q33
    # q33_index = question_indexes["q33"]
    # q33_answer = user_answers[chat_id].get(q33_index) if user_answers else None
    # q33_value = next(iter(q33_answer)) if q33_answer else None
    # if current_question == q33_index + 1:
    #     if q33_value == "улучшилась" or q33_value == "не изменилась" or q33_value == "яхшиланди" or q33_value == "ўзгармади" or q33_value == "yaxshilandi" or q33_value == "o‘zgarmadi":
    #         user_current_question[chat_id] = question_indexes["q35"]
    #         current_question = question_indexes["q35"]

    # # Q35
    # q35_index = question_indexes["q35"]
    # q35_answer = user_answers[chat_id].get(q35_index) if user_answers else None
    # q35_value = next(iter(q35_answer)) if q35_answer else None
    # if current_question == q35_index + 1:
    #     if q35_value == "нет" or q35_value == "затрудняюсь ответить":
    #         user_current_question[chat_id] = question_indexes["q37"]
    #         current_question = question_indexes["q37"]
    #     elif q35_value == "йўқ" or q35_value == "жавоб беришим қийин":
    #         user_current_question[chat_id] = question_indexes["q37"]
    #         current_question = question_indexes["q37"]
    #     elif q35_value == "yo‘q" or q35_value == "javob berishim qiyin":
    #         user_current_question[chat_id] = question_indexes["q37"]
    #         current_question = question_indexes["q37"]

    # # Q38
    # q38_index = question_indexes["q38"]
    # q38_answer = user_answers[chat_id].get(q38_index) if user_answers else None
    # q38_value = next(iter(q38_answer)) if q38_answer else None
    # if current_question == q38_index + 1:
    #     if q38_value == "нет" or q38_value == "затрудняюсь ответить":
    #         user_current_question[chat_id] = question_indexes["q39"] + 4
    #         current_question = question_indexes["q39"] + 4
    #     elif q38_value == "йўқ" or q38_value == "жавоб беришим қийин":
    #         user_current_question[chat_id] = question_indexes["q39"] + 4
    #         current_question = question_indexes["q39"] + 4
    #     elif q38_value == "yo‘q" or q38_value == "javob berishim qiyin":
    #         user_current_question[chat_id] = question_indexes["q39"] + 4
    #         current_question = question_indexes["q39"] + 4

    if lang == "uz_kiril":
        if current_question < len(questions_uz):
            question = questions_uz[current_question]
            return bot.send_message(chat_id, f"{question['number']}. {question['question']}", reply_markup=generate_markup(current_question, question["answers"]))
        else:
            return send_survey_finish_message(chat_id)
    elif lang[chat_id] == "ru":
        if current_question < len(questions):
            question = questions[current_question]
            return bot.send_message(chat_id, f"{question['number']}. {question['question']}", reply_markup=generate_markup(current_question, question["answers"]))
        else:
            return send_survey_finish_message(chat_id)
    elif lang[chat_id] == "uz_latin":
        if current_question < len(questions_uz_latin):
            question = questions_uz_latin[current_question]
            return bot.send_message(chat_id, f"{question['number']}. {question['question']}", reply_markup=generate_markup(current_question, question["answers"]))
        else:
            return send_survey_finish_message(chat_id)


# Handler for inline keyboard button clicks
@bot.callback_query_handler(func=lambda call: True)
def handle_callback_query(call):
    chat_id = call.message.chat.id
    user = select_user(chat_id)
    lang = user[0][2]
    try:
        if call.data == "ru" or call.data == "uz_kiril" or call.data == "uz_latin":
            set_language(chat_id, call.data)
            return send_question(chat_id)
        
        question_idx, answer, select = call.data.split('_')
        new_record(chat_id, question_idx, "question_text", answer, lang)
        # if select == "selected":
        #     if int(question_idx) == question_indexes["q8"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q2"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q10"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q22"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q24"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q28"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q34"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q36"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     elif int(question_idx) == question_indexes["q39"]:
        #         user_answers[chat_id][int(question_idx)].remove(answer)
        #     else:
        #         return
        # Update user_answers dictionary
        # if select != "selected" and int(question_idx) not in user_answers[chat_id]:
        #     user_answers[chat_id][int(question_idx)] = set()
        # if int(question_idx) not in user_answers[chat_id]:
        #     user_answers[chat_id][int(question_idx)] = set()
        # answers = user_answers[chat_id][int(question_idx)]

        # if int(question_idx) == question_indexes["q2"]:
        #     pass
        # elif int(question_idx) == question_indexes["q8"]:
        #     pass
        # elif int(question_idx) == question_indexes["q10"]:
        #     pass
        # elif int(question_idx) == question_indexes["q22"]:
        #     pass
        # elif int(question_idx) == question_indexes["q24"]:
        #     pass
        # elif int(question_idx) == question_indexes["q28"]:
        #     pass
        # elif int(question_idx) == question_indexes["q32"]:
        #     pass
        # elif int(question_idx) == question_indexes["q34"]:
        #     pass
        # elif int(question_idx) == question_indexes["q36"]:
        #     pass
        # elif int(question_idx) == question_indexes["q39"]:
        #     pass
        # else:
        #     answers.clear()

        # if select != "selected":
        #     answers.add(answer)

        selected_symbol = "🔘"

        if int(question_idx) == question_indexes["q2"] or int(question_idx) == question_indexes["q10"] or int(question_idx) == question_indexes["q24"] or int(question_idx) == question_indexes["q8"] or int(question_idx) == question_indexes["q22"] or int(question_idx) == question_indexes["q28"] or int(question_idx) == question_indexes["q34"] or int(question_idx) == question_indexes["q36"] or int(question_idx) == question_indexes["q39"]:
            selected_symbol = "☑️"
        elif int(question_idx) == question_indexes["q2_next"] or int(question_idx) == question_indexes["q10_next"] or int(question_idx) == question_indexes["q24_next"] or int(question_idx) == question_indexes["next"] or int(question_idx) == question_indexes["q22_next"] or int(
                question_idx) == question_indexes["q28_next"] or int(question_idx) == question_indexes["q34_next"] or int(
                question_idx) == question_indexes["q36_next"] or int(question_idx) == question_indexes["q39_next"]:
            selected_symbol = ">>"

        if answer != user_answers.get(question_idx):
            # Change the button state from ⚪️ to 🔘
            if lang == "ru":
                markup = generate_markup(question_idx, questions[int(question_idx)]["answers"])
                for row in markup.keyboard:
                    for button in row:
                        btn_idx, a, select = button.callback_data.split('_')
                        if a in user_answers[chat_id][int(question_idx)]:
                            button.text = f"{selected_symbol} {a}"
                            button.callback_data = f"{btn_idx}_{a}_selected"

                bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)
            elif lang == "uz_kiril":
                markup = generate_markup(question_idx, questions_uz[int(question_idx)]["answers"])
                for row in markup.keyboard:
                    for button in row:
                        btn_idx, a, select = button.callback_data.split('_')
                        if a in user_answers[chat_id][int(question_idx)]:
                            button.text = f"{selected_symbol} {a}"
                            button.callback_data = f"{btn_idx}_{a}_selected"

                bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)

            elif lang == "uz_latin":
                markup = generate_markup(question_idx, questions_uz_latin[int(question_idx)]["answers"])
                for row in markup.keyboard:
                    for button in row:
                        btn_idx, a, select = button.callback_data.split('_')
                        if a in user_answers[chat_id][int(question_idx)]:
                            button.text = f"{selected_symbol} {a}"
                            button.callback_data = f"{btn_idx}_{a}_selected"

                bot.edit_message_reply_markup(call.message.chat.id, call.message.message_id, reply_markup=markup)


        # Q8
        q8_answer = user_answers[chat_id].get(question_indexes["q8"]) if user_answers else None
        q8_a1 = "ипотечный кредит" in q8_answer or "ипотека кредити" in q8_answer or "ipoteka krediti" in q8_answer if q8_answer else False
        q8_a2 = "автокредит" in q8_answer or "автокредит" in q8_answer or "avtokredit" in q8_answer if q8_answer else False
        q8_a3 = "др. потребительские кредиты" in q8_answer or "истеъмол кредитлари" in q8_answer or "iste’mol kreditlari" in q8_answer if q8_answer else False
        q8_a4 = "микрозайм" in q8_answer or "микроқарз" in q8_answer or "mikroqarz" in q8_answer if q8_answer else False
        q8_a5 = "другое" in q8_answer or "бошқалар" in q8_answer or "boshqalar" in q8_answer if q8_answer else False

        # Q2
        q2_answer = user_answers[chat_id].get(question_indexes["q2"]) if user_answers else None
        q2_a1 = "сельское хозяйство" in q2_answer or "қишлоқ хўжалиги" in q2_answer or "qishloq xo'jaligi" in q2_answer if q2_answer else False
        q2_a2 = "промышленность" in q2_answer or "саноат" in q2_answer or "sanoat" in q2_answer if q2_answer else False
        q2_a3 = "строительство" in q2_answer or "қурилиш" in q2_answer or "qurilish" in q2_answer if q2_answer else False
        q2_a4 = "торговля" in q2_answer or "савдо" in q2_answer or "savdo" in q2_answer if q2_answer else False
        q2_a5 = "перевозка и хранение" in q2_answer or "ташиш ва сақлаш" in q2_answer or "tashish va saqlash" in q2_answer if q2_answer else False
        q2_a6 = "услуги по проживанию" in q2_answer or "яшаш бўйича хизматлар" in q2_answer or "yashash bo‘yicha xizmatlar" in q2_answer if q2_answer else False
        q2_a7 = "информация и связь" in q2_answer or "ахборот ва алоқа" in q2_answer or "axborot va aloqa" in q2_answer if q2_answer else False
        q2_a8 = "финансовая деятельность" in q2_answer or "молиявий фаолият" in q2_answer or "moliyaviy faoliyat" in q2_answer if q2_answer else False
        q2_a9 = "образование" in q2_answer or "таълим" in q2_answer or "ta’lim" in q2_answer if q2_answer else False
        q2_a10 = "здравоохр. и соц. услуги" in q2_answer or "ижтимоий хизматлар" in q2_answer or "ijtimoiy xizmatlar" in q2_answer if q2_answer else False
        q2_a11 = "искусство и развлечения" in q2_answer or "санъат ва кўнгил очиш" in q2_answer or "san’at va ko‘ngil ochish" in q2_answer if q2_answer else False
        q2_a12 = "индив. предпринимательство" in q2_answer or "якка тартиб. тадбиркорлик" in q2_answer or "yakka tartib. tadbirkorlik" in q2_answer if q2_answer else False
        q2_a13 = "другое" in q2_answer or "бошқалар" in q2_answer or "boshqalar" in q2_answer if q2_answer else False

        idx = int(question_idx) if question_idx else None
        curr_question = int(user_current_question.get(chat_id)) if user_current_question else None
        # Update the current question for the user
        if idx == curr_question:
            if idx == question_indexes["q8"] - 1:
                if answer != 'йўқ' or answer != "yo'q" or answer != "да":
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
            # Q2 options conditions
            elif idx == question_indexes["q2_next"] and q2_answer is not None:
                if q2_a1:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a2:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a3:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a4:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a5:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a6:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a7:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 9
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 10
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 11
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 12
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 13
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 14
                    send_question(chat_id)

            elif idx == question_indexes["q2_a1"] and q2_answer is not None:
                if q2_a2:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a3:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a4:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a5:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a6:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a7:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 9
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 10
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 11
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 12
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 13
                    send_question(chat_id)

            elif idx == question_indexes["q2_a2"] and q2_answer is not None:
                if q2_a3:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a4:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a5:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a6:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a7:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 9
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 10
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 11
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 12
                    send_question(chat_id)
            elif idx == question_indexes["q2_a3"] and q2_answer is not None:
                if q2_a4:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a5:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a6:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a7:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 9
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 10
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 11
                    send_question(chat_id)

            elif idx == question_indexes["q2_a4"] and q2_answer is not None:
                if q2_a5:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a6:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a7:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 9
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 10
                    send_question(chat_id)

            elif idx == question_indexes["q2_a5"] and q2_answer is not None:
                if q2_a6:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a7:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 9
                    send_question(chat_id)

            elif idx == question_indexes["q2_a6"] and q2_answer is not None:
                if q2_a7:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a8:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 8
                    send_question(chat_id)

            elif idx == question_indexes["q2_a7"] and q2_answer is not None:
                if q2_a8:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a9:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 7
                    send_question(chat_id)

            elif idx == question_indexes["q2_a8"] and q2_answer is not None:
                if q2_a9:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a10:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 6
                    send_question(chat_id)

            elif idx == question_indexes["q2_a9"] and q2_answer is not None:
                if q2_a10:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a11:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 5
                    send_question(chat_id)

            elif idx == question_indexes["q2_a10"] and q2_answer is not None:
                if q2_a11:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a12:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 4
                    send_question(chat_id)

            elif idx == question_indexes["q2_a11"] and q2_answer is not None:
                if q2_a12:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                elif q2_a13:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 3
                    send_question(chat_id)

            elif idx == question_indexes["q2_a12"] and q2_answer is not None:
                if q2_a13:
                    user_current_question[chat_id] += 1
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 2
                    send_question(chat_id)

            elif idx == question_indexes["q2_a13"] and q2_answer is not None:
                user_current_question[chat_id] += 1
                send_question(chat_id)

            # Q9 conditions
            elif idx == question_indexes["q9"] and answer == 'нет' and q8_answer is not None:
                if q8_a1:
                    user_current_question[chat_id] += 3
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a2:
                    user_current_question[chat_id] += 5
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a3:
                    user_current_question[chat_id] += 7
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a4:
                    user_current_question[chat_id] += 9
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a5:
                    user_current_question[chat_id] += 11
                    # Send next question if available, else end survey
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 13
                    # Send next question if available, else end survey
                    send_question(chat_id)
            elif idx == question_indexes["q10_next"] and q8_answer is not None:
                if q8_a1:
                    user_current_question[chat_id] += 1
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a2:
                    user_current_question[chat_id] += 3
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a3:
                    user_current_question[chat_id] += 5
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a4:
                    user_current_question[chat_id] += 7
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a5:
                    user_current_question[chat_id] += 9
                    # Send next question if available, else end survey
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 11
                    # Send next question if available, else end survey
                    send_question(chat_id)
            elif idx == question_indexes["q12"]:
                if q8_a2:
                    user_current_question[chat_id] += 1
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a3:
                    user_current_question[chat_id] += 3
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a4:
                    user_current_question[chat_id] += 5
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a5:
                    user_current_question[chat_id] += 7
                    # Send next question if available, else end survey
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 9
                    # Send next question if available, else end survey
                    send_question(chat_id)
            elif idx == question_indexes["q14"]:
                if q8_a3:
                    user_current_question[chat_id] += 1
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a4:
                    user_current_question[chat_id] += 3
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a5:
                    user_current_question[chat_id] += 5
                    # Send next question if available, else end survey
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 7
                    # Send next question if available, else end survey
                    send_question(chat_id)
            elif idx == question_indexes["q16"]:
                if q8_a4:
                    user_current_question[chat_id] += 1
                    # Send next question if available, else end survey
                    send_question(chat_id)
                elif q8_a5:
                    user_current_question[chat_id] += 3
                    # Send next question if available, else end survey
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 5
                    # Send next question if available, else end survey
                    send_question(chat_id)
            elif idx == question_indexes["q18"]:
                if q8_a5:
                    user_current_question[chat_id] += 1
                    # Send next question if available, else end survey
                    send_question(chat_id)
                else:
                    user_current_question[chat_id] += 3
                    # Send next question if available, else end survey
                    send_question(chat_id)
            else:
                user_current_question[chat_id] += 1
                # Send next question if available, else end survey
                send_question(chat_id)
        return
    except Exception as error:
        print("Something went wrong in callback data handling!", error)
        return bot.send_message(call.message.chat.id, "Кутилмаган хатолик! Ботимизда сўровномани бошлаш учун /start буйруғини юборинг.\n\n"
                                                      "Неожиданная ошибка! Отправьте команду /start чтобы начать опрос на нашем боте.")


if __name__ == "__main__":
    # Start the bot
    bot.polling(none_stop=True, interval=0)
